rootProject.name = "Internship2024TestCases"
include("ModuleA")
include("ModuleB")
