plugins {
    id("java")
}

version = "1.0"

repositories {
    mavenCentral()
}
dependencies {
    implementation("commons-io:commons-io:2.16.1")
}