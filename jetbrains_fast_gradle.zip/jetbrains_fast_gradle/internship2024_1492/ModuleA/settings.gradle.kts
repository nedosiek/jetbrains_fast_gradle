rootProject.name = "ModuleA"

