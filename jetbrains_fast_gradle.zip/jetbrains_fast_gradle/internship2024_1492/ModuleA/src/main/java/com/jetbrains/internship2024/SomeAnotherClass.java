package com.jetbrains.internship2024;

import com.jetbrains.internship2024.another.ClassA;

public class SomeAnotherClass {
    public static void main(String[] args) {
        new ClassA().doAnotherA();
    }
}
