package com.jetbrains.internship2024;

public class InternalClassA {
    void doInternal() {
        new ClassA().sayHello();
    }
}
