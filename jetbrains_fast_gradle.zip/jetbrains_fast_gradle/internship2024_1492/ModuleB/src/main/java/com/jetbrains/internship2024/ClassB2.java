package com.jetbrains.internship2024;

public class ClassB2 {
    public void doB2() {
        new ClassB1().doB1();
    }
}
