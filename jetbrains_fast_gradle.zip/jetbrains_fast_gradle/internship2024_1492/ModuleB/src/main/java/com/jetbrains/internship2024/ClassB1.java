package com.jetbrains.internship2024;

public class ClassB1 {
    public void doB1() {
        new ClassB2().doB2();
    }
}
