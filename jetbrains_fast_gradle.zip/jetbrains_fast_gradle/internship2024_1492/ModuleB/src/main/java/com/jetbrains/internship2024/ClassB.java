package com.jetbrains.internship2024;

public class ClassB {
    public static void main(String[] args) throws Exception {
        ClassA.main(args);
    }
}
