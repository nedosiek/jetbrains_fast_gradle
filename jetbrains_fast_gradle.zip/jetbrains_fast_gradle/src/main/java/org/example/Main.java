package org.example;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.util.ConfigurationBuilder;

import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) throws MalformedURLException {
        if (args.length < 1) {
            System.out.println("Usage: <MainClass> <jar1> <jar2> ... <jarN>");
            return;
        }

        String mainClass = args[0];
        File[] jarFiles = new File[args.length - 1];
        for (int i = 1; i < args.length; i++) {
            jarFiles[i - 1] = new File(args[i]);
        }

        if (checkDependencies(mainClass, jarFiles)) {
            System.out.println("Wszystkie wymagane zależności dla " + mainClass + " są obecne.");
        } else {
            System.out.println("Brakujące zależności dla " + mainClass + ".");
        }
    }

    public static boolean checkDependencies(String mainClass, File[] jarFiles) throws MalformedURLException {
        Set<String> requiredClasses = getRequiredClasses(mainClass);

        for (String requiredClass : requiredClasses) {
            boolean found = false;
            for (File jarFile : jarFiles) {
                if (containsClass(jarFile, requiredClass)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false; // Jeśli którakolwiek klasa nie jest znaleziona, zwróć false
            }
        }
        return true; // Wszystkie wymagane klasy są obecne
    }

    public static Set<String> getRequiredClasses(String mainClass) {
        Set<String> requiredClasses = new HashSet<>();
        Reflections reflections = new Reflections(mainClass, new SubTypesScanner());

        // Skanuj wszystkie metody w klasie głównej
        Class<?> clazz;
        try {
            clazz = Class.forName(mainClass);
            for (Method method : clazz.getDeclaredMethods()) {
                requiredClasses.add(method.getReturnType().getName());
                for (Class<?> paramType : method.getParameterTypes()) {
                    requiredClasses.add(paramType.getName());
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return requiredClasses;
    }

    public static boolean containsClass(File jarFile, String className) throws MalformedURLException {
        Reflections reflections = new Reflections(new ConfigurationBuilder()
                .addUrls(jarFile.toURI().toURL())
                .setScanners(new SubTypesScanner(false))
        );

        Set<String> allClasses = reflections.getAllTypes();
        return allClasses.contains(className);
    }
}

