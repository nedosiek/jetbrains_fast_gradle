rootProject.name = "jetbrains_fast_gradle"

